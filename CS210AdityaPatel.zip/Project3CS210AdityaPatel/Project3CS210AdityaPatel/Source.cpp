#include<iostream>
#include<fstream>
#include<string>

using namespace std;

// load words from file
void loadData(string fileName, string* list, int& n) {
    // open file
    ifstream inFile(fileName.c_str());
    string line;
    // read line by line
    while (inFile.eof() == false) {
        inFile >> line;
        list[n] = line;
        n++;
    }
    // close file
    inFile.close();
}


// count unique word
void countString(string* list, int n, string* ulst, int* ucount, int& k) {
    for (int i = 0; i < n; i++) {
        int j = 0;

        // finding word from unique list
        for (j = 0; j < k; j++) {
            if (ulst[j] == list[i]) {
                break;
            }
        }
        // if new word found
        // or not in unique list
        if (j == k) {
            ulst[k] = list[i];
            ucount[k] = 1;
            k++;
        }
        else {
            // increase the count of existing word
            ucount[j]++;
        }
    }


}

// display all list with its frequency
void displayAll(string* ulst, int* ucount, int k) {
    for (int i = 0; i < k; i++) {
        cout << ulst[i] << " : " << ucount[i] << endl;
    }
}

// diasplay string with minimum and maximum frequencies
void displayMinMax(string* ulst, int* ucount, int k) {
    int max = -1;// initial maximum value
    int min = 500;// initial minimum value
    int maxIndex = -1;// initial maximum index
    int minIndex = -1;// initial minimum index
    for (int i = 0; i < k; i++) {
        // finding maximum frequencies
        if (max < ucount[i]) {
            max = ucount[i];
            maxIndex = i;
        }
        // finding minimum frequencies
        if (min > ucount[i]) {
            min = ucount[i];
            minIndex = i;
        }
    }
    // display maximum and minimum
    cout << "\nMaximum frequency -> " << ulst[maxIndex] << " : " << ucount[maxIndex] << endl;
    cout << "\nMinimum frequency -> " << ulst[minIndex] << " : " << ucount[minIndex] << endl;
}

// searching word
int find(string* ulst, string str, int k) {
    for (int i = 0; i < k; i++) {
        if (ulst[i] == str) {
            return i;
        }
    }
    return -1;
}


int main() {
    //
    cout << "Enter file name : ";
    string fileName;
    cin >> fileName;

    // to store number line in file
    int n = 0;
    // to store number of unique words
    int k = 0;


    string list[500];

    // load from file
    loadData(fileName, list, n);


    string u_list[500];
    int u_n[500];

    // get unique string and corresponding frequency
    countString(list, n, u_list, u_n, k);



    while (true) {

        // display menu
        cout << "1. Display List";
        cout << "\n2. Display count the word";
        cout << "\n3. Display words with highest frequency and lowest frequency";
        cout << "\n4. Exit";
        cout << "\nChoose option [1-4]: ";
        int option;
        cin >> option;

        // for valid option
        if (option >= 1 && option <= 4) {
            // dispaly unique list
            if (option == 1) {
                displayAll(u_list, u_n, k);
            }

            // searching word from unique list
            if (option == 2) {
                string word;
                cout << "Enter word : ";
                cin >> word;
                int index = find(u_list, word, k);

                if (index == -1) {
                    cout << "Word not found.\n\n";
                }
                else {
                    cout << u_list[index] << " : " << u_n[index] << endl;
                }
            }
            // display minimum and maximum
            if (option == 3) {
                displayMinMax(u_list, u_n, k);
            }
            if (option == 4) {
                break;
            }
        }
        // for invalid option
        else {
            cout << "\nPlease choose correct option.\n";
        }
    }
    system("pause");
    return 0;
}